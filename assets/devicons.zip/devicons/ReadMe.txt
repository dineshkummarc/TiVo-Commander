Developer Icons by Matt Ball
--------------------------------

These icons are free for developers to use in their applications. I only ask that I be credited either in the app's about box or on the app's website, preferably with a link to my website: http://www.mattballdesign.com. 

I would also appreciate an email (sent to ball.matt@gmail.com) with a link to the app's page so I can see how people put these icons to use.

Releases
--------------------------------

6/09/07 - v. 1.2b	Added the URL of my website to the readme

2/15/06 - v. 1.2	Removed some controversial icons. Added General 
			Preferences, SnapBack, Stop, Users, and Reload. 
			Revised HUD.

1/29/06 - v. 1.1	Added Burn, Dashboard, RSS 2, Podcast, Photocast, 
			Movies, Linkback Green, and Linkback Green 2.
			Revised Network Utility.

1/27/06 - v. 1.0	First release